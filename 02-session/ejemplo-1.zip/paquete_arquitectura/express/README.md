# esqueleto express (node.js)
- src/api: routes + controllers + dto
- src/application: servicios y casos de uso
- src/domain: entidades y contratos de repositorios
- src/infrastructure: conexiones db, repos concretos, clientes externos
- src/shared: utilidades, middlewares
- integrations/devops/deploy/scripts/tests

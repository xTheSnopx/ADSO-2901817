# esqueleto java (spring boot)
- api: controllers (rest) y dto
- application: servicios y casos de uso
- domain: modelos y contratos (repository)
- infrastructure: jpa, repos concretos, clientes externos
- resources: configuración
- integrations/devops/deploy/scripts/tests como en los otros

# java (spring boot) hexagonal

# python (fastapi) hexagonal

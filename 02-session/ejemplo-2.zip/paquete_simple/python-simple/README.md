# esqueleto python (fastapi) simple
- api/controllers: routers
- services: reglas de negocio
- repositories: dao simple
- models: pydantic dtos + orm
- db: modelos/migraciones (sqlalchemy + alembic)
- config/utils: settings y utilidades

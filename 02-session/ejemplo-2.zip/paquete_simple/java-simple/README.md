# esqueleto java (spring boot) simple
- controller → service → repository → db
- model: entidades jpa y dtos
- config: properties/beans

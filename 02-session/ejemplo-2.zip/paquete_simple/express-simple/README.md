# esqueleto express simple
- routes + controllers
- services (negocio)
- repositories (dao)
- models (orm o esquemas)
- middlewares/config/utils según necesidad

# esqueleto .net simple (sin ddd)
capas mínimas dentro de un único proyecto `WebApi`:
- controllers: endpoints http
- services: lógica de negocio
- repositories: acceso a datos
- models: entidades simples + dtos
- data: dbcontext y migraciones (ef core)
- config: configuración
